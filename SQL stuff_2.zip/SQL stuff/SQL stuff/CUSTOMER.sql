CREATE TABLE CUSTOMER (
	CustomerID INT NOT NULL,
    FirstName VARCHAR(20) NOT NULL,
    LastName VARCHAR(20) NOT NULL,
    PhoneNum INT,
    EmailAddr VARCHAR(50),
    Street VARCHAR(50) NOT NULL,
    City VARCHAR(50) NOT NULL,
    State VARCHAR(15) NOT NULL,
    Zip INT NOT NULL,
    PRIMARY KEY(CustomerID),
    UNIQUE(CustomerID)
);