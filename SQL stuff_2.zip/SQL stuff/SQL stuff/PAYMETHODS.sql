CREATE TABLE PAYMETHODS (
	PaymentID INT NOT NULL,
    PayMethod VARCHAR(20),
    FOREIGN KEY (PaymentID) REFERENCES PAYMENTS(PaymentID) ON DELETE SET NULL ON UPDATE CASCADE
);
-- "PAYMETHODS" represents the multivalued attribute PAYMENTS.PayMethod that can contain possible values such as cash or card