CREATE TABLE PAYSTATUS (
	PaymentID INT NOT NULL,
    PayStatus VARCHAR(10),
    FOREIGN KEY (PaymentID) REFERENCES PAYMENTS(PaymentID) ON DELETE SET NULL ON UPDATE CASCADE
);

-- "PAYSTATUS" represents the multivalued attribute PAYMENTS.PayStatus that can contain possible values such as paid, unpaid, pending, etc.