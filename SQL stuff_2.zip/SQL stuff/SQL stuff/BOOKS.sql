CREATE TABLE BOOKS (
    BookID INT NOT NULL,
    Title VARCHAR(100) NOT NULL,
    Genre VARCHAR(100) NOT NULL,
    PubYear INT NOT NULL,
    Price FLOAT NOT NULL DEFAULT 0.00,
    StockQuant INT NOT NULL DEFAULT 0,
    PubName VARCHAR(100) NOT NULL,
    PubContactInformation VARCHAR(1000) NOT NULL,
    PRIMARY KEY(BookID),
    UNIQUE(BookID)
);
-- NOTES:
-- BOOKS.Name and BOOKS.PubContactInformation are composite attributes, BOOKS.Publisher
-- 