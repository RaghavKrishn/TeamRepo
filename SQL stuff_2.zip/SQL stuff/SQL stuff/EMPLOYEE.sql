CREATE TABLE Employee (
    EmployeeID INTEGER NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Position VARCHAR(100),
    HireDate VARCHAR(10) NOT NULL,
    PRIMARY KEY (EmployeeID),
    UNIQUE (EmployeeID)
);
