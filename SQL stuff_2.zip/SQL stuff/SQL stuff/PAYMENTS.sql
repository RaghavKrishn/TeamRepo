create TABLE PAYMENTS (
	PaymentID INTEGER NOT NULL,
    PaymentAmount INTEGER NOT NULL,
    PayDate VARCHAR(10) NOT NULL,
    PRIMARY KEY(PaymentID),
    UNIQUE(PaymentID)
);
